	<footer>
		<h6>Copyright &copy; 2019| Group one</h6>
	</footer>
</body>
</html>